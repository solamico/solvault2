
import { Keypair } from '@solana/web3.js';
import { useState, useCallback, useRef, useEffect } from 'react';
import bs58 from 'bs58';
import { encryptPrivateKey, decryptPrivateKey, clearSensitiveData, EncryptedData } from '../utils/cryptoUtils';

export interface GeneratedWallet {
  id: string;
  keypair: Keypair;
  publicKey: string;
  encryptedPrivateKey: EncryptedData | null;
  label: string;
  balance: number;
  isVisible: boolean;
  isLocked: boolean;
}

export const useWalletGeneration = () => {
  const [generatedWallets, setGeneratedWallets] = useState<GeneratedWallet[]>([]);
  const [masterPassword, setMasterPassword] = useState<string>('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const sensitiveDataRef = useRef<Map<string, string>>(new Map());

  // Clear sensitive data on unmount
  useEffect(() => {
    return () => {
      sensitiveDataRef.current.clear();
      clearSensitiveData(masterPassword);
    };
  }, []);

  const setWalletPassword = useCallback((password: string) => {
    setMasterPassword(password);
    setIsUnlocked(true);
  }, []);

  const lockWallets = useCallback(() => {
    setMasterPassword('');
    setIsUnlocked(false);
    sensitiveDataRef.current.clear();
    
    setGeneratedWallets(prev => prev.map(wallet => ({
      ...wallet,
      isLocked: true
    })));
  }, []);

  const unlockWallet = useCallback(async (walletId: string, password: string): Promise<string | null> => {
    const wallet = generatedWallets.find(w => w.id === walletId);
    if (!wallet || !wallet.encryptedPrivateKey) return null;

    try {
      const privateKey = await decryptPrivateKey(wallet.encryptedPrivateKey, password);
      sensitiveDataRef.current.set(walletId, privateKey);
      
      setGeneratedWallets(prev => prev.map(w => 
        w.id === walletId ? { ...w, isLocked: false } : w
      ));
      
      return privateKey;
    } catch (error) {
      console.error('Failed to unlock wallet:', error);
      return null;
    }
  }, [generatedWallets]);

  const generateWallet = useCallback(async (label?: string, password?: string): Promise<GeneratedWallet> => {
    const keypair = Keypair.generate();
    const id = `wallet-${Date.now()}-${Math.random()}`;
    const privateKey = bs58.encode(keypair.secretKey);
    
    let encryptedPrivateKey: EncryptedData | null = null;
    
    if (password) {
      encryptedPrivateKey = await encryptPrivateKey(privateKey, password);
      sensitiveDataRef.current.set(id, privateKey);
    }
    
    const wallet: GeneratedWallet = {
      id,
      keypair,
      publicKey: keypair.publicKey.toString(),
      encryptedPrivateKey,
      label: label || `Wallet ${generatedWallets.length + 1}`,
      balance: 0,
      isVisible: true,
      isLocked: !password
    };

    // Clear the original private key from memory
    clearSensitiveData(privateKey);
    
    return wallet;
  }, [generatedWallets.length]);

  const generateMultipleWallets = useCallback(async (count: number, password?: string): Promise<GeneratedWallet[]> => {
    const newWallets: GeneratedWallet[] = [];
    for (let i = 0; i < count; i++) {
      const wallet = await generateWallet(`Wallet ${generatedWallets.length + i + 1}`, password);
      newWallets.push(wallet);
    }
    setGeneratedWallets(prev => [...prev, ...newWallets]);
    return newWallets;
  }, [generateWallet, generatedWallets.length]);

  const importWallet = useCallback(async (
    privateKey: string, 
    label?: string, 
    password?: string
  ): Promise<GeneratedWallet> => {
    try {
      const secretKey = bs58.decode(privateKey);
      const keypair = Keypair.fromSecretKey(secretKey);
      const id = `wallet-${Date.now()}-imported`;
      
      let encryptedPrivateKey: EncryptedData | null = null;
      
      if (password) {
        encryptedPrivateKey = await encryptPrivateKey(privateKey, password);
        sensitiveDataRef.current.set(id, privateKey);
      }
      
      const wallet: GeneratedWallet = {
        id,
        keypair,
        publicKey: keypair.publicKey.toString(),
        encryptedPrivateKey,
        label: label || `Imported Wallet`,
        balance: 0,
        isVisible: true,
        isLocked: !password
      };

      setGeneratedWallets(prev => [...prev, wallet]);
      
      // Clear the original private key from memory
      clearSensitiveData(privateKey);
      
      return wallet;
    } catch (error) {
      clearSensitiveData(privateKey);
      throw new Error('Invalid private key format');
    }
  }, []);

  const exportWallets = useCallback(async (password: string): Promise<string> => {
    const exportData = await Promise.all(
      generatedWallets.map(async (wallet) => {
        let privateKey = '';
        
        if (wallet.encryptedPrivateKey) {
          try {
            privateKey = await decryptPrivateKey(wallet.encryptedPrivateKey, password);
          } catch (error) {
            console.error('Failed to decrypt wallet for export:', wallet.id);
            privateKey = 'ENCRYPTED_WALLET_EXPORT_FAILED';
          }
        } else {
          privateKey = sensitiveDataRef.current.get(wallet.id) || 'UNLOCKED_WALLET_NO_KEY';
        }
        
        return {
          label: wallet.label,
          publicKey: wallet.publicKey,
          privateKey
        };
      })
    );
    
    const exportString = JSON.stringify(exportData, null, 2);
    
    // Clear sensitive data after export
    exportData.forEach(item => clearSensitiveData(item.privateKey));
    
    return exportString;
  }, [generatedWallets]);

  const getDecryptedPrivateKey = useCallback((walletId: string): string | null => {
    return sensitiveDataRef.current.get(walletId) || null;
  }, []);

  return {
    generatedWallets,
    setGeneratedWallets,
    generateWallet,
    generateMultipleWallets,
    importWallet,
    exportWallets,
    setWalletPassword,
    lockWallets,
    unlockWallet,
    getDecryptedPrivateKey,
    isUnlocked,
    masterPassword
  };
};
