
import { useConnection } from '@solana/wallet-adapter-react';
import { PublicKey } from '@solana/web3.js';
import { getAssociatedTokenAddressSync } from '@solana/spl-token';
import { useState, useCallback } from 'react';

interface TokenBalance {
  mint: string;
  balance: number;
  decimals: number;
  symbol?: string;
}

export const useTokenBalances = () => {
  const { connection } = useConnection();
  const [isLoading, setIsLoading] = useState(false);

  const getSOLBalance = useCallback(async (publicKey: string): Promise<number> => {
    try {
      const pubkey = new PublicKey(publicKey);
      const balance = await connection.getBalance(pubkey);
      return balance / 1e9; // Convert lamports to SOL
    } catch (error) {
      console.error('Error fetching SOL balance:', error);
      return 0;
    }
  }, [connection]);

  const getTokenBalance = useCallback(async (
    walletPublicKey: string, 
    tokenMint: string
  ): Promise<number> => {
    try {
      const walletPubkey = new PublicKey(walletPublicKey);
      const mintPubkey = new PublicKey(tokenMint);
      
      const associatedTokenAccount = getAssociatedTokenAddressSync(
        mintPubkey,
        walletPubkey
      );

      const accountInfo = await connection.getTokenAccountBalance(associatedTokenAccount);
      if (accountInfo.value) {
        return parseFloat(accountInfo.value.amount) / Math.pow(10, accountInfo.value.decimals);
      }
      return 0;
    } catch (error) {
      console.error('Error fetching token balance:', error);
      return 0;
    }
  }, [connection]);

  const getAllTokenBalances = useCallback(async (
    walletPublicKey: string
  ): Promise<TokenBalance[]> => {
    setIsLoading(true);
    try {
      const pubkey = new PublicKey(walletPublicKey);
      const tokenAccounts = await connection.getParsedTokenAccountsByOwner(pubkey, {
        programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA')
      });

      const balances: TokenBalance[] = [];
      
      for (const account of tokenAccounts.value) {
        const parsedInfo = account.account.data.parsed.info;
        const balance = parseFloat(parsedInfo.tokenAmount.amount) / Math.pow(10, parsedInfo.tokenAmount.decimals);
        
        if (balance > 0) {
          balances.push({
            mint: parsedInfo.mint,
            balance,
            decimals: parsedInfo.tokenAmount.decimals
          });
        }
      }

      return balances;
    } catch (error) {
      console.error('Error fetching all token balances:', error);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [connection]);

  return {
    getSOLBalance,
    getTokenBalance,
    getAllTokenBalances,
    isLoading
  };
};
