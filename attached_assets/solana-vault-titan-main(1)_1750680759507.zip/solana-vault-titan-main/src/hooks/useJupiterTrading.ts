
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { PublicKey, Transaction, VersionedTransaction } from '@solana/web3.js';
import { useState } from 'react';
import { QuoteResponseSchema, SwapResponseSchema, QuoteResponse } from '../schemas/jupiterSchemas';

interface SwapParams {
  inputMint: string;
  outputMint: string;
  amount: number;
  slippageBps: number;
}

export const useJupiterTrading = () => {
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();
  const [isSwapping, setIsSwapping] = useState(false);

  const getQuote = async (params: SwapParams): Promise<QuoteResponse | null> => {
    try {
      console.log('Requesting Jupiter quote with params:', params);
      
      const response = await fetch(
        `https://quote-api.jup.ag/v6/quote?inputMint=${params.inputMint}&outputMint=${params.outputMint}&amount=${params.amount}&slippageBps=${params.slippageBps}`
      );
      
      if (!response.ok) {
        throw new Error(`Jupiter API error: ${response.status} ${response.statusText}`);
      }
      
      const rawData = await response.json();
      console.log('Raw Jupiter quote response:', rawData);
      
      // Validate the response using Zod schema
      const validatedData = QuoteResponseSchema.parse(rawData);
      console.log('Validated Jupiter quote:', validatedData);
      
      return validatedData;
    } catch (error) {
      console.error('Error getting Jupiter quote:', error);
      if (error instanceof Error) {
        console.error('Error details:', error.message);
      }
      return null;
    }
  };

  const executeSwap = async (
    quote: QuoteResponse,
    userPublicKey: PublicKey
  ): Promise<string | null> => {
    if (!publicKey) {
      throw new Error('Wallet not connected');
    }

    setIsSwapping(true);
    try {
      console.log('Executing swap with quote:', quote);
      
      // Get swap transaction from Jupiter
      const swapResponse = await fetch('https://quote-api.jup.ag/v6/swap', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          quoteResponse: quote,
          userPublicKey: userPublicKey.toString(),
          wrapAndUnwrapSol: true,
        }),
      });

      if (!swapResponse.ok) {
        throw new Error(`Jupiter swap API error: ${swapResponse.status} ${swapResponse.statusText}`);
      }

      const rawSwapData = await swapResponse.json();
      console.log('Raw Jupiter swap response:', rawSwapData);
      
      // Validate the swap response
      const validatedSwapData = SwapResponseSchema.parse(rawSwapData);
      console.log('Validated Jupiter swap data:', validatedSwapData);
      
      const { swapTransaction } = validatedSwapData;
      
      // Deserialize the transaction
      const transactionBuf = Buffer.from(swapTransaction, 'base64');
      const transaction = VersionedTransaction.deserialize(transactionBuf);
      
      // Send transaction
      const signature = await sendTransaction(transaction, connection, {
        maxRetries: 3,
        preflightCommitment: 'processed',
      });

      console.log('Swap transaction sent:', signature);

      // Wait for confirmation
      const confirmation = await connection.confirmTransaction(signature, 'confirmed');
      
      if (confirmation.value.err) {
        throw new Error(`Swap failed: ${confirmation.value.err}`);
      }

      console.log('Swap successful:', signature);
      return signature;

    } catch (error) {
      console.error('Swap execution error:', error);
      if (error instanceof Error) {
        console.error('Error details:', error.message);
      }
      throw error;
    } finally {
      setIsSwapping(false);
    }
  };

  const swapSOLToToken = async (
    tokenMint: string,
    solAmount: number,
    slippageBps: number = 300
  ): Promise<string | null> => {
    if (!publicKey) {
      throw new Error('Wallet not connected');
    }

    // Validate inputs
    if (solAmount <= 0) {
      throw new Error('SOL amount must be greater than 0');
    }
    
    if (slippageBps < 0 || slippageBps > 10000) {
      throw new Error('Slippage must be between 0 and 10000 basis points');
    }

    const SOL_MINT = 'So11111111111111111111111111111111111111112';
    const amountInLamports = Math.floor(solAmount * 1e9);

    console.log(`Swapping ${solAmount} SOL to ${tokenMint}`);

    const quote = await getQuote({
      inputMint: SOL_MINT,
      outputMint: tokenMint,
      amount: amountInLamports,
      slippageBps
    });

    if (!quote) {
      throw new Error('Failed to get quote from Jupiter');
    }

    return executeSwap(quote, publicKey);
  };

  const swapTokenToSOL = async (
    tokenMint: string,
    tokenAmount: number,
    decimals: number,
    slippageBps: number = 300
  ): Promise<string | null> => {
    if (!publicKey) {
      throw new Error('Wallet not connected');
    }

    // Validate inputs
    if (tokenAmount <= 0) {
      throw new Error('Token amount must be greater than 0');
    }
    
    if (decimals < 0 || decimals > 18) {
      throw new Error('Decimals must be between 0 and 18');
    }

    const SOL_MINT = 'So11111111111111111111111111111111111111112';
    const amountInSmallestUnit = Math.floor(tokenAmount * Math.pow(10, decimals));

    console.log(`Swapping ${tokenAmount} ${tokenMint} to SOL`);

    const quote = await getQuote({
      inputMint: tokenMint,
      outputMint: SOL_MINT,
      amount: amountInSmallestUnit,
      slippageBps
    });

    if (!quote) {
      throw new Error('Failed to get quote from Jupiter');
    }

    return executeSwap(quote, publicKey);
  };

  return {
    getQuote,
    executeSwap,
    swapSOLToToken,
    swapTokenToSOL,
    isSwapping
  };
};
