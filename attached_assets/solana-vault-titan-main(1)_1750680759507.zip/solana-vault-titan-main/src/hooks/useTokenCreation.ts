
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { 
  createInitializeMintInstruction,
  createAssociatedTokenAccountInstruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  getMinimumBalanceForRentExemptMint,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  AuthorityType,
  getAssociatedTokenAddressSync
} from '@solana/spl-token';
import { 
  Keypair, 
  Transaction, 
  SystemProgram,
  PublicKey
} from '@solana/web3.js';
import { useState } from 'react';

interface TokenCreationParams {
  name: string;
  symbol: string;
  decimals: number;
  totalSupply: string;
  description: string;
  revokeMintAuthority: boolean;
  revokeFreezeAuthority: boolean;
}

export const useTokenCreation = () => {
  const { publicKey, sendTransaction } = useWallet();
  const { connection } = useConnection();
  const [isCreating, setIsCreating] = useState(false);
  const [createdToken, setCreatedToken] = useState<string | null>(null);

  const createToken = async (params: TokenCreationParams) => {
    if (!publicKey) {
      throw new Error('Wallet not connected');
    }

    setIsCreating(true);
    try {
      console.log('Creating token with params:', params);

      // Generate new mint keypair
      const mintKeypair = Keypair.generate();
      console.log('Generated mint keypair:', mintKeypair.publicKey.toString());

      // Get the minimum lamports for rent exemption
      const lamports = await getMinimumBalanceForRentExemptMint(connection);

      // Create transaction
      const transaction = new Transaction();

      // Add instruction to create account for the mint
      transaction.add(
        SystemProgram.createAccount({
          fromPubkey: publicKey,
          newAccountPubkey: mintKeypair.publicKey,
          space: MINT_SIZE,
          lamports,
          programId: TOKEN_PROGRAM_ID,
        })
      );

      // Add instruction to initialize the mint
      transaction.add(
        createInitializeMintInstruction(
          mintKeypair.publicKey,
          params.decimals,
          publicKey, // mint authority
          publicKey  // freeze authority
        )
      );

      // Get associated token account address
      const associatedTokenAccount = getAssociatedTokenAddressSync(
        mintKeypair.publicKey,
        publicKey
      );

      console.log('Associated token account:', associatedTokenAccount.toString());

      // Add instruction to create associated token account
      transaction.add(
        createAssociatedTokenAccountInstruction(
          publicKey, // payer
          associatedTokenAccount,
          publicKey, // owner
          mintKeypair.publicKey
        )
      );

      // Add mint instruction if total supply > 0
      if (params.totalSupply && parseFloat(params.totalSupply) > 0) {
        const mintAmount = BigInt(parseFloat(params.totalSupply) * Math.pow(10, params.decimals));
        
        transaction.add(
          createMintToInstruction(
            mintKeypair.publicKey,
            associatedTokenAccount,
            publicKey,
            mintAmount
          )
        );

        console.log('Added mint instruction for amount:', mintAmount.toString());
      }

      // Add authority revocation instructions if requested
      if (params.revokeMintAuthority) {
        transaction.add(
          createSetAuthorityInstruction(
            mintKeypair.publicKey,
            publicKey,
            AuthorityType.MintTokens,
            null
          )
        );
        console.log('Added mint authority revocation instruction');
      }

      if (params.revokeFreezeAuthority) {
        transaction.add(
          createSetAuthorityInstruction(
            mintKeypair.publicKey,
            publicKey,
            AuthorityType.FreezeAccount,
            null
          )
        );
        console.log('Added freeze authority revocation instruction');
      }

      // Send transaction
      transaction.feePayer = publicKey;
      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
      transaction.recentBlockhash = blockhash;
      
      // Partially sign with mint keypair
      transaction.partialSign(mintKeypair);

      // Send transaction through wallet
      const signature = await sendTransaction(transaction, connection, {
        maxRetries: 3,
        preflightCommitment: 'processed',
      });
      console.log('Transaction sent:', signature);

      // Wait for confirmation with better error handling
      try {
        const confirmation = await connection.confirmTransaction({
          signature,
          blockhash,
          lastValidBlockHeight,
        }, 'confirmed');

        if (confirmation.value.err) {
          throw new Error(`Transaction failed: ${confirmation.value.err}`);
        }

        console.log('Transaction confirmed:', signature);
        setCreatedToken(mintKeypair.publicKey.toString());
        
        return {
          mintAddress: mintKeypair.publicKey.toString(),
          tokenAccount: associatedTokenAccount.toString(),
          signature,
          success: true
        };

      } catch (timeoutError) {
        console.warn('Transaction timeout, checking if it succeeded...');
        
        // Check if transaction actually succeeded despite timeout
        try {
          const sigStatus = await connection.getSignatureStatus(signature);
          if (sigStatus.value?.confirmationStatus === 'confirmed' || sigStatus.value?.confirmationStatus === 'finalized') {
            console.log('Transaction actually succeeded despite timeout');
            setCreatedToken(mintKeypair.publicKey.toString());
            
            return {
              mintAddress: mintKeypair.publicKey.toString(),
              tokenAccount: associatedTokenAccount.toString(),
              signature,
              success: true
            };
          }
        } catch (checkError) {
          console.error('Error checking transaction status:', checkError);
        }
        
        throw timeoutError;
      }

    } catch (error) {
      console.error('Error creating token:', error);
      throw error;
    } finally {
      setIsCreating(false);
    }
  };

  return {
    createToken,
    isCreating,
    createdToken,
    setCreatedToken
  };
};
