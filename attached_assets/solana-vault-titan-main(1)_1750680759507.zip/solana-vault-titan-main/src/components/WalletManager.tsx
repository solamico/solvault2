import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import TokenTrading from './TokenTrading';
import WalletImportExport from './WalletImportExport';
import { 
  Wallet, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw,
  Settings,
  Eye,
  EyeOff
} from 'lucide-react';
import { useWalletGeneration, GeneratedWallet } from '../hooks/useWalletGeneration';
import { useTokenBalances } from '../hooks/useTokenBalances';

const WalletManager = () => {
  const { 
    generatedWallets, 
    setGeneratedWallets,
    generateMultipleWallets 
  } = useWalletGeneration();
  const { getSOLBalance } = useTokenBalances();
  const [selectedWallets, setSelectedWallets] = useState<Set<string>>(new Set());
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshBalances = async () => {
    setIsRefreshing(true);
    try {
      const updatedWallets = await Promise.all(
        generatedWallets.map(async (wallet) => {
          const balance = await getSOLBalance(wallet.publicKey);
          return { ...wallet, balance };
        })
      );
      setGeneratedWallets(updatedWallets);
    } catch (error) {
      console.error('Error refreshing balances:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const generateWallets = (count: number) => {
    generateMultipleWallets(count);
  };

  const toggleWalletSelection = (id: string) => {
    const newSelected = new Set(selectedWallets);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedWallets(newSelected);
  };

  const selectAllWallets = () => {
    if (selectedWallets.size === generatedWallets.length) {
      setSelectedWallets(new Set());
    } else {
      setSelectedWallets(new Set(generatedWallets.map(w => w.id)));
    }
  };

  const toggleWalletVisibility = (id: string) => {
    setGeneratedWallets(prev => prev.map(wallet => 
      wallet.id === id ? { ...wallet, isVisible: !wallet.isVisible } : wallet
    ));
  };

  // Auto-refresh balances when wallets change
  useEffect(() => {
    if (generatedWallets.length > 0) {
      refreshBalances();
    }
  }, [generatedWallets.length]);

  return (
    <div className="space-y-6">
      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Wallets</p>
                <p className="text-2xl font-bold text-white">{generatedWallets.length}</p>
              </div>
              <Wallet className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Balance</p>
                <p className="text-2xl font-bold text-white">
                  {generatedWallets.reduce((sum, w) => sum + w.balance, 0).toFixed(3)} SOL
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Selected</p>
                <p className="text-2xl font-bold text-white">{selectedWallets.size}</p>
              </div>
              <Settings className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Avg Balance</p>
                <p className="text-2xl font-bold text-white">
                  {generatedWallets.length > 0 ? (generatedWallets.reduce((sum, w) => sum + w.balance, 0) / generatedWallets.length).toFixed(3) : '0.000'} SOL
                </p>
              </div>
              <TrendingDown className="w-8 h-8 text-amber-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="wallets" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800/50 border border-slate-700">
          <TabsTrigger 
            value="wallets" 
            className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            Wallet Management
          </TabsTrigger>
          <TabsTrigger 
            value="trading"
            className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            Token Trading
          </TabsTrigger>
          <TabsTrigger 
            value="advanced"
            className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            Advanced Features
          </TabsTrigger>
        </TabsList>

        <TabsContent value="wallets" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Wallet Controls */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Wallet Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={() => generateWallets(1)}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Generate Wallet
                </Button>

                <Button 
                  onClick={() => generateWallets(10)}
                  variant="outline"
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  Generate 10 Wallets
                </Button>

                <WalletImportExport onWalletImported={refreshBalances} />

                <Button 
                  onClick={selectAllWallets}
                  variant="outline"
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  {selectedWallets.size === generatedWallets.length ? 'Deselect All' : 'Select All'}
                </Button>

                <div className="pt-4 border-t border-slate-700">
                  <p className="text-slate-400 text-sm mb-2">Quick Actions</p>
                  <Button 
                    onClick={refreshBalances}
                    disabled={isRefreshing}
                    variant="outline" 
                    size="sm"
                    className="w-full border-slate-600 text-slate-300 mb-2"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                    {isRefreshing ? 'Refreshing...' : 'Refresh Balances'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Wallet List */}
            <div className="lg:col-span-3">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white">Managed Wallets ({generatedWallets.length})</CardTitle>
                    <Badge variant="secondary" className="bg-purple-500/10 text-purple-400 border-purple-500/20">
                      {selectedWallets.size} selected
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  {generatedWallets.length === 0 ? (
                    <div className="text-center py-12">
                      <Wallet className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                      <p className="text-slate-400 mb-2">No wallets generated yet</p>
                      <p className="text-slate-500 text-sm">Generate your first wallet to get started</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {generatedWallets.map((wallet) => (
                        <div 
                          key={wallet.id}
                          className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                            selectedWallets.has(wallet.id)
                              ? 'bg-purple-500/10 border-purple-500/20'
                              : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <input
                              type="checkbox"
                              checked={selectedWallets.has(wallet.id)}
                              onChange={() => toggleWalletSelection(wallet.id)}
                              className="rounded border-slate-600"
                            />
                            <div>
                              <p className="text-white font-medium">{wallet.label}</p>
                              <p className="text-slate-400 text-sm font-mono">
                                {wallet.isVisible 
                                  ? `${wallet.publicKey.slice(0, 8)}...${wallet.publicKey.slice(-8)}`
                                  : '•••••••••••••••••'
                                }
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="text-right">
                              <p className="text-white font-semibold">
                                {wallet.isVisible ? `${wallet.balance.toFixed(3)} SOL` : '•••••'}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleWalletVisibility(wallet.id)}
                              className="text-slate-400 hover:text-white"
                            >
                              {wallet.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="trading" className="space-y-6">
          <TokenTrading 
            selectedWallets={selectedWallets} 
            wallets={generatedWallets}
          />
        </TabsContent>

        <TabsContent value="advanced" className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Advanced Trading Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Settings className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400 mb-2">Advanced Features Coming Soon</p>
                <p className="text-slate-500 text-sm">
                  Features like Jupiter DEX integration, MEV protection, and advanced trading strategies
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WalletManager;
