
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { PasswordInput } from './ui/password-input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Upload, Download, Key, AlertTriangle, Shield, Lock } from 'lucide-react';
import { useWalletGeneration } from '../hooks/useWalletGeneration';
import { clearSensitiveData } from '../utils/cryptoUtils';

interface WalletImportExportProps {
  onWalletImported: () => void;
}

const WalletImportExport = ({ onWalletImported }: WalletImportExportProps) => {
  const { importWallet, exportWallets, isUnlocked, setWalletPassword } = useWalletGeneration();
  const [importKey, setImportKey] = useState('');
  const [importLabel, setImportLabel] = useState('');
  const [importPassword, setImportPassword] = useState('');
  const [exportPassword, setExportPassword] = useState('');
  const [masterPassword, setMasterPasswordState] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [importError, setImportError] = useState('');
  const [showPasswordSetup, setShowPasswordSetup] = useState(!isUnlocked);

  const handleSetMasterPassword = () => {
    if (masterPassword.length < 8) {
      setImportError('Master password must be at least 8 characters long');
      return;
    }
    setWalletPassword(masterPassword);
    setShowPasswordSetup(false);
    setImportError('');
  };

  const handleImport = async () => {
    if (!importKey.trim()) {
      setImportError('Please enter a private key');
      return;
    }

    if (!importPassword.trim()) {
      setImportError('Please enter a password to encrypt this wallet');
      return;
    }

    setIsImporting(true);
    setImportError('');

    try {
      await importWallet(importKey.trim(), importLabel.trim() || undefined, importPassword.trim());
      
      // Clear sensitive data
      clearSensitiveData(importKey);
      clearSensitiveData(importPassword);
      
      setImportKey('');
      setImportLabel('');
      setImportPassword('');
      onWalletImported();
    } catch (error) {
      setImportError(error instanceof Error ? error.message : 'Failed to import wallet');
    } finally {
      setIsImporting(false);
    }
  };

  const handleExport = async () => {
    if (!exportPassword.trim()) {
      setImportError('Please enter your master password to decrypt wallets for export');
      return;
    }

    setIsExporting(true);
    setImportError('');

    try {
      const exportData = await exportWallets(exportPassword.trim());
      const blob = new Blob([exportData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `solana-wallets-encrypted-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      // Clear sensitive data
      clearSensitiveData(exportPassword);
      setExportPassword('');
    } catch (error) {
      setImportError('Failed to export wallets. Please check your password.');
    } finally {
      setIsExporting(false);
    }
  };

  if (showPasswordSetup) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Shield className="w-5 h-5 mr-2 text-green-400" />
            Setup Master Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
            <div className="flex items-center mb-2">
              <Lock className="w-4 h-4 text-blue-400 mr-2" />
              <span className="text-blue-400 text-sm font-medium">Enhanced Security</span>
            </div>
            <p className="text-blue-200 text-xs">
              Set a master password to encrypt all wallet private keys. This adds an extra layer of security.
            </p>
          </div>

          <div>
            <Label className="text-slate-300">Master Password (min 8 characters)</Label>
            <PasswordInput
              value={masterPassword}
              onChange={setMasterPasswordState}
              placeholder="Create a strong master password..."
              className="bg-slate-700 border-slate-600 text-white"
              required
              autoComplete="new-password"
            />
          </div>

          {importError && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
              <p className="text-red-400 text-sm">{importError}</p>
            </div>
          )}

          <Button 
            onClick={handleSetMasterPassword}
            disabled={masterPassword.length < 8}
            className="w-full bg-gradient-to-r from-green-600 to-green-700"
          >
            Setup Secure Wallet Manager
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="flex space-x-2">
      <Dialog>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            size="sm"
            className="border-slate-600 text-slate-300"
          >
            <Upload className="w-4 h-4 mr-1" />
            Import
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <Key className="w-5 h-5 mr-2" />
              Import Encrypted Wallet
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
              <div className="flex items-center mb-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 mr-2" />
                <span className="text-amber-400 text-sm font-medium">Security Notice</span>
              </div>
              <p className="text-amber-200 text-xs">
                Private keys will be encrypted with your password. Never share your private keys or passwords.
              </p>
            </div>

            <div>
              <Label className="text-slate-300">Private Key (Base58)</Label>
              <Textarea
                placeholder="Enter your base58 encoded private key..."
                value={importKey}
                onChange={(e) => setImportKey(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 font-mono text-sm"
                rows={3}
                spellCheck={false}
                autoComplete="off"
              />
            </div>

            <div>
              <Label className="text-slate-300">Wallet Label (Optional)</Label>
              <Input
                placeholder="My Imported Wallet"
                value={importLabel}
                onChange={(e) => setImportLabel(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                autoComplete="off"
              />
            </div>

            <div>
              <Label className="text-slate-300">Encryption Password</Label>
              <PasswordInput
                value={importPassword}
                onChange={setImportPassword}
                placeholder="Password to encrypt this wallet..."
                className="bg-slate-700 border-slate-600 text-white"
                required
                autoComplete="new-password"
              />
            </div>

            {importError && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                <p className="text-red-400 text-sm">{importError}</p>
              </div>
            )}

            <Button 
              onClick={handleImport}
              disabled={isImporting || !importKey.trim() || !importPassword.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700"
            >
              {isImporting ? 'Importing...' : 'Import Encrypted Wallet'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            size="sm"
            className="border-slate-600 text-slate-300"
          >
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <Shield className="w-5 h-5 mr-2" />
              Export Encrypted Wallets
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <div className="flex items-center mb-2">
                <Shield className="w-4 h-4 text-green-400 mr-2" />
                <span className="text-green-400 text-sm font-medium">Secure Export</span>
              </div>
              <p className="text-green-200 text-xs">
                Your wallets will be exported with their encrypted private keys. Keep your passwords safe.
              </p>
            </div>

            <div>
              <Label className="text-slate-300">Master Password</Label>
              <PasswordInput
                value={exportPassword}
                onChange={setExportPassword}
                placeholder="Enter your master password..."
                className="bg-slate-700 border-slate-600 text-white"
                required
                autoComplete="current-password"
              />
            </div>

            {importError && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                <p className="text-red-400 text-sm">{importError}</p>
              </div>
            )}

            <Button 
              onClick={handleExport}
              disabled={isExporting || !exportPassword.trim()}
              className="w-full bg-gradient-to-r from-green-600 to-green-700"
            >
              {isExporting ? 'Exporting...' : 'Export Encrypted Wallets'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WalletImportExport;
