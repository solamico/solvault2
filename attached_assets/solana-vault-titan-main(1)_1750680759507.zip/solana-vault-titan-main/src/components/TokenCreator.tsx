import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { useTokenCreation } from '../hooks/useTokenCreation';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Upload, Coins, Settings, CheckCircle, ExternalLink, Copy } from 'lucide-react';

const TokenCreator = () => {
  const { connected } = useWallet();
  const { createToken, isCreating, createdToken, setCreatedToken } = useTokenCreation();
  
  const [tokenData, setTokenData] = useState({
    name: '',
    symbol: '',
    decimals: 9,
    totalSupply: '',
    description: '',
    revokeMintAuthority: false,
    revokeFreezeAuthority: false
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (field: string, value: any) => {
    setTokenData(prev => ({ ...prev, [field]: value }));
  };

  const handleCreateToken = async () => {
    if (!connected) {
      setError('Please connect your wallet first');
      return;
    }

    try {
      setError(null);
      const result = await createToken(tokenData);
      console.log('Token created successfully:', result);
      setCurrentStep(5); // Success step
    } catch (error) {
      console.error('Token creation failed:', error);
      setError(error instanceof Error ? error.message : 'Token creation failed');
    }
  };

  const resetForm = () => {
    setCurrentStep(1);
    setCreatedToken(null);
    setError(null);
    setTokenData({
      name: '',
      symbol: '',
      decimals: 9,
      totalSupply: '',
      description: '',
      revokeMintAuthority: false,
      revokeFreezeAuthority: false
    });
  };

  const steps = [
    { id: 1, title: 'Token Details', icon: Coins },
    { id: 2, title: 'Metadata & Media', icon: Upload },
    { id: 3, title: 'Authority Settings', icon: Settings },
    { id: 4, title: 'Review & Create', icon: CheckCircle }
  ];

  // Success step
  if (currentStep === 5 && createdToken) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-white">Token Created Successfully!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-slate-700/50 rounded-lg p-4 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Token Address:</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm">
                  {`${createdToken.slice(0, 6)}...${createdToken.slice(-6)}`}
                </span>
                <button
                  onClick={() => navigator.clipboard.writeText(createdToken)}
                  className="text-slate-400 hover:text-white"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={() => window.open(`https://explorer.solana.com/address/${createdToken}?cluster=devnet`, '_blank')}
                  className="text-slate-400 hover:text-white"
                >
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex space-x-4">
            <Button 
              onClick={resetForm}
              className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700"
            >
              Create Another Token
            </Button>
            <Button 
              variant="outline"
              onClick={() => window.open(`https://explorer.solana.com/address/${createdToken}?cluster=devnet`, '_blank')}
              className="border-slate-600 text-slate-300"
            >
              View on Explorer
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && (
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="p-4">
            <p className="text-red-400 text-sm">{error}</p>
          </CardContent>
        </Card>
      )}

      {/* Wallet Connection Warning */}
      {!connected && (
        <Card className="bg-amber-500/10 border-amber-500/20">
          <CardContent className="p-4">
            <p className="text-amber-400 text-sm text-center">
              Please connect your wallet to create SPL tokens
            </p>
          </CardContent>
        </Card>
      )}

      {/* Progress Indicator */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  currentStep >= step.id 
                    ? 'border-purple-500 bg-purple-500 text-white' 
                    : 'border-slate-600 text-slate-400'
                }`}>
                  <step.icon className="w-5 h-5" />
                </div>
                <div className="ml-3">
                  <p className={`text-sm font-medium ${
                    currentStep >= step.id ? 'text-white' : 'text-slate-400'
                  }`}>
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-12 h-0.5 mx-4 ${
                    currentStep > step.id ? 'bg-purple-500' : 'bg-slate-600'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <Progress 
            value={(currentStep / steps.length) * 100} 
            className="w-full h-2 bg-slate-700"
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {currentStep === 1 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Coins className="w-5 h-5 mr-2" />
                  Token Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-slate-300">Token Name</Label>
                    <Input
                      id="name"
                      placeholder="My Awesome Token"
                      value={tokenData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                    />
                  </div>
                  <div>
                    <Label htmlFor="symbol" className="text-slate-300">Symbol</Label>
                    <Input
                      id="symbol"
                      placeholder="MAT"
                      value={tokenData.symbol}
                      onChange={(e) => handleInputChange('symbol', e.target.value.toUpperCase())}
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="decimals" className="text-slate-300">Decimals</Label>
                    <Input
                      id="decimals"
                      type="number"
                      min="0"
                      max="18"
                      value={tokenData.decimals}
                      onChange={(e) => handleInputChange('decimals', parseInt(e.target.value))}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="supply" className="text-slate-300">Total Supply</Label>
                    <Input
                      id="supply"
                      placeholder="1000000"
                      value={tokenData.totalSupply}
                      onChange={(e) => handleInputChange('totalSupply', e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description" className="text-slate-300">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your token..."
                    value={tokenData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={() => setCurrentStep(2)}
                  disabled={!tokenData.name || !tokenData.symbol || !connected}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                >
                  Continue to Metadata
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 2 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Upload className="w-5 h-5 mr-2" />
                  Metadata & Media
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center">
                  <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-300 mb-2">Upload Token Image</p>
                  <p className="text-slate-500 text-sm">PNG, JPG up to 2MB (Coming Soon)</p>
                  <Button variant="outline" className="mt-4 border-slate-600 text-slate-300" disabled>
                    Choose File
                  </Button>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentStep(1)}
                    className="border-slate-600 text-slate-300"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={() => setCurrentStep(3)}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                  >
                    Continue to Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {currentStep === 3 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  Authority Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-slate-300 text-base">Revoke Mint Authority</Label>
                      <p className="text-slate-500 text-sm">Prevent future minting</p>
                    </div>
                    <Switch
                      checked={tokenData.revokeMintAuthority}
                      onCheckedChange={(checked) => handleInputChange('revokeMintAuthority', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-slate-300 text-base">Revoke Freeze Authority</Label>
                      <p className="text-slate-500 text-sm">Prevent freezing tokens</p>
                    </div>
                    <Switch
                      checked={tokenData.revokeFreezeAuthority}
                      onCheckedChange={(checked) => handleInputChange('revokeFreezeAuthority', checked)}
                    />
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentStep(2)}
                    className="border-slate-600 text-slate-300"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={() => setCurrentStep(4)}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                  >
                    Review & Create
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {currentStep === 4 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Review & Create Token
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-700/50 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Name:</span>
                    <span className="text-white">{tokenData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Symbol:</span>
                    <span className="text-white">{tokenData.symbol}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Supply:</span>
                    <span className="text-white">{tokenData.totalSupply}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Decimals:</span>
                    <span className="text-white">{tokenData.decimals}</span>
                  </div>
                </div>

                <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4">
                  <p className="text-amber-400 text-sm">
                    ⚠️ Creating a token on devnet is free for testing. Mainnet costs approximately 0.002 SOL.
                  </p>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentStep(3)}
                    className="border-slate-600 text-slate-300"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={handleCreateToken}
                    disabled={isCreating || !connected}
                    className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                  >
                    {isCreating ? 'Creating Token...' : 'Create Token'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Preview Panel */}
        <div className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-lg">Token Preview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-green-400 rounded-full mx-auto mb-3 flex items-center justify-center">
                  <span className="text-white font-bold text-xl">
                    {tokenData.symbol ? tokenData.symbol[0] : '?'}
                  </span>
                </div>
                <h3 className="text-white font-semibold">
                  {tokenData.name || 'Token Name'}
                </h3>
                <p className="text-slate-400 text-sm">
                  {tokenData.symbol || 'SYMBOL'}
                </p>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Supply:</span>
                  <span className="text-white">
                    {tokenData.totalSupply ? `${tokenData.totalSupply} ${tokenData.symbol}` : 'Not set'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Decimals:</span>
                  <span className="text-white">{tokenData.decimals}</span>
                </div>
              </div>

              {(tokenData.revokeMintAuthority || tokenData.revokeFreezeAuthority) && (
                <div className="space-y-2">
                  {tokenData.revokeMintAuthority && (
                    <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">
                      Mint Authority Revoked
                    </Badge>
                  )}
                  {tokenData.revokeFreezeAuthority && (
                    <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">
                      Freeze Authority Revoked
                    </Badge>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-lg">Network Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Network:</span>
                <span className="text-white">Devnet (Testing)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Token Creation:</span>
                <span className="text-white">Free</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Transaction Fee:</span>
                <span className="text-white">~0.000005 SOL</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TokenCreator;
