
import React, { useEffect, useState } from 'react';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { Wallet, Copy, ExternalLink } from 'lucide-react';
import { LAMPORTS_PER_SOL } from '@solana/web3.js';

const WalletConnection = () => {
  const { publicKey, connected, disconnect } = useWallet();
  const { connection } = useConnection();
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => {
    if (connected && publicKey) {
      // Fetch real SOL balance
      connection.getBalance(publicKey).then((balance) => {
        setBalance(balance / LAMPORTS_PER_SOL);
      }).catch((error) => {
        console.error('Error fetching balance:', error);
      });
    } else {
      setBalance(null);
    }
  }, [connected, publicKey, connection]);

  const copyAddress = async () => {
    if (publicKey) {
      await navigator.clipboard.writeText(publicKey.toString());
      // You could add a toast notification here
    }
  };

  const openExplorer = () => {
    if (publicKey) {
      window.open(`https://explorer.solana.com/address/${publicKey.toString()}?cluster=devnet`, '_blank');
    }
  };

  if (!connected) {
    return (
      <div className="wallet-adapter-button-trigger">
        <WalletMultiButton className="!bg-gradient-to-r !from-purple-600 !to-purple-700 hover:!from-purple-700 hover:!to-purple-800 !text-white !border-none !rounded-md" />
      </div>
    );
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardContent className="p-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
            <Wallet className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">
                Connected
              </Badge>
              <span className="text-slate-400 text-sm">
                {balance !== null ? `${balance.toFixed(4)} SOL` : 'Loading...'}
              </span>
            </div>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-white text-sm font-mono">
                {publicKey ? `${publicKey.toString().slice(0, 4)}...${publicKey.toString().slice(-4)}` : ''}
              </span>
              <button 
                onClick={copyAddress}
                className="text-slate-400 hover:text-white"
                title="Copy address"
              >
                <Copy className="w-3 h-3" />
              </button>
              <button 
                onClick={openExplorer}
                className="text-slate-400 hover:text-white"
                title="View on Solana Explorer"
              >
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={disconnect}
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            Disconnect
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default WalletConnection;
