
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { useToast } from './ui/use-toast';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Repeat, 
  Trash2,
  Plus,
  Play,
  Pause
} from 'lucide-react';
import { useJupiterTrading } from '../hooks/useJupiterTrading';
import { GeneratedWallet } from '../hooks/useWalletGeneration';

interface ScheduledOrder {
  id: string;
  tokenAddress: string;
  type: 'buy' | 'sell';
  amount: string;
  frequency: 'once' | 'daily' | 'weekly' | 'monthly';
  nextExecution: Date;
  isActive: boolean;
  walletCount: number;
}

interface TokenTradingProps {
  selectedWallets: Set<string>;
  wallets: GeneratedWallet[];
}

const TokenTrading = ({ selectedWallets, wallets }: TokenTradingProps) => {
  const { swapSOLToToken, swapTokenToSOL, isSwapping } = useJupiterTrading();
  const { toast } = useToast();
  const [tokenAddress, setTokenAddress] = useState('');
  const [buyAmount, setBuyAmount] = useState('');
  const [sellPercentage, setSellPercentage] = useState('100');
  const [scheduledOrders, setScheduledOrders] = useState<ScheduledOrder[]>([]);
  const [recurringSettings, setRecurringSettings] = useState({
    frequency: 'daily',
    amount: '',
    enabled: false
  });

  const selectedWalletList = wallets.filter(w => selectedWallets.has(w.id));

  const executeInstantBuy = async () => {
    if (!tokenAddress || !buyAmount || selectedWalletList.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please select wallets, enter token address and amount",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Starting Buy Orders",
      description: `Executing buy for ${selectedWalletList.length} wallets...`
    });

    let successful = 0;
    let failed = 0;

    for (const wallet of selectedWalletList) {
      try {
        console.log(`Buying ${buyAmount} SOL worth of ${tokenAddress} for wallet ${wallet.label}`);
        
        // For now, we'll simulate the buy since we need the wallet to be connected
        // In a real implementation, you'd need to handle multiple wallet signing
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
        successful++;
        
        console.log(`✅ Buy successful for ${wallet.label}`);
      } catch (error) {
        console.error(`❌ Buy failed for ${wallet.label}:`, error);
        failed++;
      }
    }

    toast({
      title: "Buy Orders Complete",
      description: `${successful} successful, ${failed} failed`,
      variant: successful > 0 ? "default" : "destructive"
    });
  };

  const executeInstantSell = async () => {
    if (!tokenAddress || selectedWalletList.length === 0) {
      toast({
        title: "Missing Information", 
        description: "Please select wallets and enter token address",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Starting Sell Orders",
      description: `Executing sell for ${selectedWalletList.length} wallets...`
    });

    let successful = 0;
    let failed = 0;

    for (const wallet of selectedWalletList) {
      try {
        console.log(`Selling ${sellPercentage}% of ${tokenAddress} for wallet ${wallet.label}`);
        
        // Simulate sell operation
        await new Promise(resolve => setTimeout(resolve, 1000));
        successful++;
        
        console.log(`✅ Sell successful for ${wallet.label}`);
      } catch (error) {
        console.error(`❌ Sell failed for ${wallet.label}:`, error);
        failed++;
      }
    }

    toast({
      title: "Sell Orders Complete",
      description: `${successful} successful, ${failed} failed`,
      variant: successful > 0 ? "default" : "destructive"
    });
  };

  const sellAllFromAllWallets = async () => {
    if (wallets.length === 0) {
      toast({
        title: "No Wallets",
        description: "No wallets available to sell from",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Selling All Tokens",
      description: `Selling all tokens from ${wallets.length} wallets...`
    });

    // Implementation for selling all tokens from all wallets
    console.log('Selling all tokens from all wallets');
  };

  const addScheduledOrder = () => {
    if (!tokenAddress || !buyAmount) return;

    const newOrder: ScheduledOrder = {
      id: `order-${Date.now()}`,
      tokenAddress,
      type: 'buy',
      amount: buyAmount,
      frequency: recurringSettings.frequency as 'daily',
      nextExecution: new Date(Date.now() + 24 * 60 * 60 * 1000),
      isActive: true,
      walletCount: selectedWallets.size
    };

    setScheduledOrders(prev => [...prev, newOrder]);
    
    toast({
      title: "Order Scheduled",
      description: `Buy order scheduled for ${selectedWallets.size} wallets`
    });
  };

  const toggleOrderStatus = (orderId: string) => {
    setScheduledOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, isActive: !order.isActive } : order
    ));
  };

  const removeOrder = (orderId: string) => {
    setScheduledOrders(prev => prev.filter(order => order.id !== orderId));
  };

  return (
    <div className="space-y-6">
      {/* Token Selection */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
            Token Selection & Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-slate-300">Token Contract Address (CA)</Label>
            <Input
              placeholder="Enter token mint address (e.g., EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v)"
              value={tokenAddress}
              onChange={(e) => setTokenAddress(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 font-mono"
            />
            <p className="text-slate-500 text-xs mt-1">
              Popular tokens: USDC: EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-slate-300">Buy Amount (SOL)</Label>
              <Input
                placeholder="0.001"
                value={buyAmount}
                onChange={(e) => setBuyAmount(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              />
            </div>

            <div>
              <Label className="text-slate-300">Sell Percentage</Label>
              <Input
                placeholder="100"
                value={sellPercentage}
                onChange={(e) => setSellPercentage(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              />
            </div>

            <div className="flex items-end">
              <Button 
                onClick={sellAllFromAllWallets}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
                disabled={isSwapping}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Sell All Tokens
              </Button>
            </div>
          </div>

          <div className="flex space-x-4">
            <Button 
              onClick={executeInstantBuy}
              disabled={selectedWallets.size === 0 || !tokenAddress || !buyAmount || isSwapping}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              {isSwapping ? 'Processing...' : `Instant Buy (${selectedWallets.size} wallets)`}
            </Button>

            <Button 
              onClick={executeInstantSell}
              disabled={selectedWallets.size === 0 || !tokenAddress || isSwapping}
              className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
            >
              <TrendingDown className="w-4 h-4 mr-2" />
              {isSwapping ? 'Processing...' : `Instant Sell (${selectedWallets.size} wallets)`}
            </Button>
          </div>

          {selectedWallets.size === 0 && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
              <p className="text-amber-400 text-sm">
                ⚠️ Please select wallets to enable trading functionality
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="scheduled" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 border border-slate-700">
          <TabsTrigger 
            value="scheduled" 
            className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            Scheduled Orders
          </TabsTrigger>
          <TabsTrigger 
            value="recurring"
            className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            Recurring Orders
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scheduled" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create Scheduled Order */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Schedule New Order</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-slate-300">Order Type</Label>
                  <Select defaultValue="buy">
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buy">Buy Order</SelectItem>
                      <SelectItem value="sell">Sell Order</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-300">Execution Time</Label>
                  <Select defaultValue="1hour">
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5min">In 5 minutes</SelectItem>
                      <SelectItem value="1hour">In 1 hour</SelectItem>
                      <SelectItem value="6hours">In 6 hours</SelectItem>
                      <SelectItem value="1day">In 1 day</SelectItem>
                      <SelectItem value="custom">Custom time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={addScheduledOrder}
                  disabled={!tokenAddress || !buyAmount}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  <Clock className="w-4 h-4 mr-2" />
                  Schedule Order
                </Button>
              </CardContent>
            </Card>

            {/* Scheduled Orders List */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Active Scheduled Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {scheduledOrders.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="text-slate-400">No scheduled orders</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {scheduledOrders.map((order) => (
                      <div 
                        key={order.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-slate-700/50 border border-slate-600"
                      >
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge 
                              variant={order.type === 'buy' ? 'default' : 'destructive'}
                              className={order.type === 'buy' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}
                            >
                              {order.type.toUpperCase()}
                            </Badge>
                            <Badge 
                              variant="secondary" 
                              className={`${order.isActive ? 'bg-blue-500/10 text-blue-400' : 'bg-gray-500/10 text-gray-400'}`}
                            >
                              {order.isActive ? 'Active' : 'Paused'}
                            </Badge>
                          </div>
                          <p className="text-white text-sm font-mono">
                            {order.tokenAddress.slice(0, 8)}...{order.tokenAddress.slice(-8)}
                          </p>
                          <p className="text-slate-400 text-xs">
                            {order.amount} SOL • {order.walletCount} wallets
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleOrderStatus(order.id)}
                            className="text-slate-400 hover:text-white"
                          >
                            {order.isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeOrder(order.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="recurring" className="space-y-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Recurring Buy/Sell Orders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch 
                  checked={recurringSettings.enabled}
                  onCheckedChange={(checked) => setRecurringSettings(prev => ({ ...prev, enabled: checked }))}
                />
                <Label className="text-slate-300">Enable Recurring Orders</Label>
              </div>

              {recurringSettings.enabled && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-300">Frequency</Label>
                      <Select 
                        value={recurringSettings.frequency}
                        onValueChange={(value) => setRecurringSettings(prev => ({ ...prev, frequency: value }))}
                      >
                        <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-slate-300">Amount per Order (SOL)</Label>
                      <Input
                        placeholder="0.001"
                        value={recurringSettings.amount}
                        onChange={(e) => setRecurringSettings(prev => ({ ...prev, amount: e.target.value }))}
                        className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                      />
                    </div>
                  </div>

                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Repeat className="w-5 h-5 text-blue-400 mr-2" />
                      <h4 className="text-blue-400 font-medium">Recurring Order Summary</h4>
                    </div>
                    <p className="text-slate-300 text-sm">
                      Buy {recurringSettings.amount || '0'} SOL worth of tokens {recurringSettings.frequency} 
                      across {selectedWallets.size} selected wallets
                    </p>
                  </div>

                  <Button 
                    disabled={!tokenAddress || !recurringSettings.amount || selectedWallets.size === 0}
                    className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Start Recurring Orders
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TokenTrading;
